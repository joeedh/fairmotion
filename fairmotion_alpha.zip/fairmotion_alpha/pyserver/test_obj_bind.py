proxy_cls = """
class ObjProxy (object):
  def __init__(self, obj, methodmap):
    self.methodmap = methodmap
    self.proxy = obj
    
  def __getattribute__(self, attr):
    print("GETATTR")
    proxy = object.__getattribute__(self, "proxy")
    methodmap = object.__getattribute__(self, "methodmap")
    
    print(methodmap)
    if attr in methodmap:
      methodmap[attr](attr)
    
    return object.__getattribute__(proxy, attr)
"""

specials = [
  "__str__", "__repr__", "__len__", ["__getitem__", "item"], 
  ["__setitem__", "item, val"], ["__hasitem__", "item"],
  ["__eq__", "b"], "__hash__", "__iter__", ["__neq__", "b"],
  ["__contains__", "item"], ["__delitem__", "item"],
  ["__lt__", "b"], ["__gt__", "b"], ["__le__", "b"], ["__ge__", "b"]
]

for k in specials:
  args1 = args2 = ""
  if type(k) in [list, tuple]:
    k, args = k
    args1 = ", " + args
    args2 = args
    
  proxy_cls += """
  def K(selfARGS1):
    attr = "K"
    proxy = object.__getattribute__(self, "proxy")
    methodmap = object.__getattribute__(self, "methodmap")
    
    if attr in methodmap:
      methodmap[attr](attr)
    
    return object.__getattribute__(proxy, attr)(ARGS2)
  """.replace("K", k).replace("ARGS1", args1).replace("ARGS2", args2)

exec(proxy_cls)

def f(t):
  print(t + " accessed!")
  
a = ["a"]
a.append("sd")
a = ObjProxy(a, {"append" : f})
print(a.append)
print(a, len(a), a[0], list(a))
