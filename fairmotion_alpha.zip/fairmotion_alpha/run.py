#!/usr/bin/env python
#!/usr/bin/env python
import os, os.path, sys

path = os.path.abspath(os.path.normpath(os.getcwd()))

os.chdir("pyserver")
sys.path.append(os.getcwd())

if not os.path.exists("config_local.py"):
  print("generating config_local.py...")
  buf = """
serverhost = "127.0.0.1"
serverport = 8080

base_path = "/"
server_root = r"ROOT/pyserver"
doc_root = r"ROOT"

#this isn't used unless you turn off serv_all_local
files_root = r"ROOT/userfiles"

ipaddr = "127.0.0.1"
  """.replace("ROOT", path)
  f = open("config_local.py", "w")
  f.write(buf)
  f.close()
  
import serv_simple
